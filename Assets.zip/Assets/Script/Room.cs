﻿namespace KBEngine
{
    using System.Collections;
    using System.Collections.Generic;
    using UnityEngine;

    public class Room : KBEngine.RoomBase
    {
		
    }
}
